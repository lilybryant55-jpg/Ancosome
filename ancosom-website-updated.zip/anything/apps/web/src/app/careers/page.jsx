import { useState } from "react";
import {
  ArrowLeft,
  MapPin,
  Clock,
  Briefcase,
  ChevronDown,
  ExternalLink,
} from "lucide-react";

const openings = [
  {
    id: 1,
    title: "Senior Civil Engineer",
    department: "Civil Engineering",
    location: "Abuja, FCT",
    type: "Full-time",
    description:
      "Lead civil engineering design and supervision for road construction, drainage, and earthworks projects. Requires COREN registration and 7+ years of experience.",
    requirements: [
      "BSc/BEng in Civil Engineering",
      "COREN registered",
      "7+ years of field experience",
      "Proficiency in AutoCAD and Civil 3D",
      "Strong project management skills",
    ],
  },
  {
    id: 2,
    title: "Structural Design Engineer",
    department: "Structural Engineering",
    location: "Lagos",
    type: "Full-time",
    description:
      "Responsible for structural analysis and design of reinforced concrete and steel structures. Must have experience with ETABS, SAP2000, or similar software.",
    requirements: [
      "BSc/BEng in Structural/Civil Engineering",
      "3+ years of structural design experience",
      "Proficiency in ETABS, SAP2000, or Tekla",
      "Knowledge of British and Eurocode standards",
    ],
  },
  {
    id: 3,
    title: "Project Manager",
    department: "Project Management",
    location: "Abuja, FCT",
    type: "Full-time",
    description:
      "Oversee end-to-end project delivery including scheduling, cost control, quality assurance, and client coordination for multiple construction projects.",
    requirements: [
      "BSc in Engineering or Construction Management",
      "PMP certification preferred",
      "5+ years in construction project management",
      "Strong leadership and communication skills",
    ],
  },
  {
    id: 4,
    title: "Site Supervisor",
    department: "Construction",
    location: "Nationwide",
    type: "Full-time",
    description:
      "Supervise construction activities on-site, ensuring quality standards, safety compliance, and adherence to project schedules.",
    requirements: [
      "OND/HND in Civil Engineering or Building Technology",
      "3+ years of on-site supervision experience",
      "Knowledge of construction safety protocols",
      "Ability to work in remote locations",
    ],
  },
];

export default function CareersPage() {
  const [openId, setOpenId] = useState(null);

  const toggle = (id) => setOpenId(openId === id ? null : id);

  return (
    <div className="font-inter bg-white min-h-screen">
      {/* Top Bar */}
      <div className="border-b border-[#E5E7EB]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <a
            href="/"
            className="inline-flex items-center gap-2 text-[#6B7280] hover:text-[#111827] transition-colors font-inter text-sm"
          >
            <ArrowLeft size={16} />
            Back to Home
          </a>
        </div>
      </div>

      {/* Header */}
      <div className="bg-[#0f172a] py-16 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="inline-flex items-center gap-2 bg-white/10 border border-white/20 rounded-full px-3 py-1.5 mb-4">
            <span className="w-1.5 h-1.5 bg-[#2563EB] rounded-full" />
            <span className="font-inter text-xs font-medium text-white/80">
              Careers
            </span>
          </div>
          <h1 className="font-inter font-semibold text-3xl lg:text-4xl text-white tracking-tight">
            Join Our Team
          </h1>
          <p className="font-inter text-sm text-white/60 mt-3 max-w-xl leading-relaxed">
            Build your career with one of Nigeria's growing engineering and
            construction companies. We're looking for talented professionals who
            share our commitment to excellence.
          </p>
          <div className="flex flex-wrap gap-3 mt-6">
            <span className="inline-flex items-center gap-1.5 bg-white/10 border border-white/20 rounded-full px-3 py-1.5 text-xs font-inter text-white/80">
              <Briefcase size={12} />
              {openings.length} Open Positions
            </span>
            <span className="inline-flex items-center gap-1.5 bg-white/10 border border-white/20 rounded-full px-3 py-1.5 text-xs font-inter text-white/80">
              <MapPin size={12} />
              Multiple Locations
            </span>
          </div>
        </div>
      </div>

      {/* Job Listings */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <h2 className="font-inter font-semibold text-xl text-[#111827] tracking-tight mb-6">
          Open Positions
        </h2>

        <div className="space-y-3">
          {openings.map((job) => {
            const isOpen = openId === job.id;
            return (
              <div
                key={job.id}
                className="bg-white rounded-xl border border-[#E5E7EB] overflow-hidden"
              >
                <button
                  onClick={() => toggle(job.id)}
                  className="w-full flex items-center justify-between px-6 py-5 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
                >
                  <div>
                    <h3 className="font-inter font-semibold text-base text-[#111827]">
                      {job.title}
                    </h3>
                    <div className="flex flex-wrap items-center gap-2 mt-2">
                      <span className="inline-flex items-center gap-1 bg-[#EFF6FF] rounded-full px-2.5 py-1 text-[10px] font-inter font-medium text-[#2563EB]">
                        {job.department}
                      </span>
                      <span className="inline-flex items-center gap-1 bg-white border border-[#E5E7EB] rounded-full px-2.5 py-1 text-[10px] font-inter text-[#6B7280]">
                        <MapPin size={10} />
                        {job.location}
                      </span>
                      <span className="inline-flex items-center gap-1 bg-white border border-[#E5E7EB] rounded-full px-2.5 py-1 text-[10px] font-inter text-[#6B7280]">
                        <Clock size={10} />
                        {job.type}
                      </span>
                    </div>
                  </div>
                  <ChevronDown
                    size={18}
                    className={`text-[#6B7280] flex-shrink-0 transition-transform duration-200 ${
                      isOpen ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-6 pb-6 border-t border-[#E5E7EB] pt-5">
                    <p className="font-inter text-sm text-[#6B7280] leading-relaxed">
                      {job.description}
                    </p>
                    <h4 className="font-inter font-semibold text-sm text-[#111827] mt-4 mb-2">
                      Requirements
                    </h4>
                    <ul className="space-y-1.5">
                      {job.requirements.map((req) => (
                        <li
                          key={req}
                          className="flex items-start gap-2 font-inter text-sm text-[#4B5563]"
                        >
                          <span className="text-[#9CA3AF] mr-1">-</span>
                          {req}
                        </li>
                      ))}
                    </ul>
                    <a
                      href="mailto:ancosomenigltd@yahoo.com"
                      className="inline-flex items-center gap-2 bg-[#2563EB] text-white font-inter font-medium text-sm px-5 py-2.5 rounded-lg hover:bg-[#1d4ed8] transition-colors mt-5"
                    >
                      Apply Now
                      <ExternalLink size={14} />
                    </a>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* General Application */}
        <div className="mt-10 bg-[#F9FAFB] rounded-xl border border-[#E5E7EB] p-8 text-center">
          <h3 className="font-inter font-semibold text-lg text-[#111827]">
            Don't See a Suitable Role?
          </h3>
          <p className="font-inter text-sm text-[#6B7280] mt-2 max-w-md mx-auto">
            Send your CV and a cover letter to our HR team. We're always looking
            for exceptional talent.
          </p>
          <a
            href="mailto:ancosomenigltd@yahoo.com"
            className="inline-flex items-center gap-2 bg-[#2563EB] text-white font-inter font-medium text-sm px-5 py-2.5 rounded-lg hover:bg-[#1d4ed8] transition-colors mt-5"
          >
            Send Your CV
          </a>
        </div>
      </div>

      {/* Footer */}
      <div className="border-t border-[#E5E7EB] py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="font-inter text-xs text-[#9CA3AF]">
            © {new Date().getFullYear()} ANCOSOM NIGERIA LIMITED
            Engineering Ltd. All Rights Reserved.
          </p>
        </div>
      </div>
    </div>
  );
}
