import Navbar from "../components/Navbar";
import HeroSection from "../components/HeroSection";
import AboutSection from "../components/AboutSection";
import ServicesSection from "../components/ServicesSection";
import WhyChooseUs from "../components/WhyChooseUs";
import ProjectsSection from "../components/ProjectsSection";
import ProcessSection from "../components/ProcessSection";
import IndustriesSection from "../components/IndustriesSection";
import TestimonialsSection from "../components/TestimonialsSection";
import FAQSection from "../components/FAQSection";
import ContactSection from "../components/ContactSection";
import Footer from "../components/Footer";
import WhatsAppButton from "../components/WhatsAppButton";
import BackToTop from "../components/BackToTop";

const HERO_IMAGE =
  "https://raw.createusercontent.com/bff7d2d4-3186-4a63-b7b2-f1e3c1476a11/";
const TEAM_IMAGE =
  "https://raw.createusercontent.com/f6b02672-8ddc-4afe-aee8-056172c01e8c/";
const LOGO_IMAGE =
  "https://raw.createusercontent.com/f76f14e2-ef45-41b9-81bb-a0cde30b13f8/";

const PROJECT_IMAGES = [
  "https://raw.createusercontent.com/64ff74a7-c4b0-4839-8293-8032472cfebf/",
  "https://raw.createusercontent.com/dbc2240a-113e-44a6-84ab-bf812a034f44/",
  "https://raw.createusercontent.com/24c935db-c242-47e7-b577-cdacc5a164ac/",
  "https://raw.createusercontent.com/93ad0c85-83e9-4411-8893-ee71290ed2be/",
  "https://raw.createusercontent.com/08e51cd7-52fb-4b6b-b750-bc5b7b6ea55a/",
  "https://raw.createusercontent.com/bff7d2d4-3186-4a63-b7b2-f1e3c1476a11/",
];

export default function HomePage() {
  return (
    <div
      className="font-inter bg-white min-h-screen"
      style={{ overflowX: "hidden" }}
    >
      <Navbar logoUrl={LOGO_IMAGE} />
      <HeroSection heroImage={HERO_IMAGE} />
      <AboutSection teamImage={TEAM_IMAGE} />
      <ServicesSection />
      <WhyChooseUs />
      <ProjectsSection projectImages={PROJECT_IMAGES} />
      <ProcessSection />
      <IndustriesSection />
      <TestimonialsSection />
      <FAQSection />
      <ContactSection />
      <Footer logoUrl={LOGO_IMAGE} />
      <WhatsAppButton />
      <BackToTop />
    </div>
  );
}
