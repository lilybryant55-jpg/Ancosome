import { useState } from "react";
import { ArrowLeft, Clock, User, ArrowRight, Search } from "lucide-react";

const blogPosts = [
  {
    id: 1,
    title: "5 Key Considerations for Road Construction in Nigeria",
    excerpt:
      "Understanding soil conditions, drainage requirements, and traffic load analysis are critical factors in delivering durable road infrastructure across Nigeria's diverse terrain.",
    category: "Civil Engineering",
    author: "Engr. David Okafor",
    date: "June 10, 2026",
    readTime: "6 min read",
    image:
      "https://raw.createusercontent.com/64ff74a7-c4b0-4839-8293-8032472cfebf/",
  },
  {
    id: 2,
    title: "The Role of Structural Engineering in Modern Building Safety",
    excerpt:
      "How advanced structural analysis techniques and reinforced concrete design ensure buildings withstand environmental loads and seismic activity.",
    category: "Structural Engineering",
    author: "Engr. Amina Suleiman",
    date: "May 28, 2026",
    readTime: "8 min read",
    image:
      "https://raw.createusercontent.com/08e51cd7-52fb-4b6b-b750-bc5b7b6ea55a/",
  },
  {
    id: 3,
    title: "Sustainable Construction Practices for the Nigerian Market",
    excerpt:
      "Exploring eco-friendly materials, energy-efficient designs, and waste reduction strategies that are reshaping the Nigerian construction industry.",
    category: "Innovation",
    author: "Engr. Chukwudi Eze",
    date: "May 15, 2026",
    readTime: "5 min read",
    image:
      "https://raw.createusercontent.com/dbc2240a-113e-44a6-84ab-bf812a034f44/",
  },
  {
    id: 4,
    title: "Project Management Best Practices for Construction Firms",
    excerpt:
      "Effective scheduling, cost control, and stakeholder communication are the pillars of successful construction project delivery.",
    category: "Project Management",
    author: "Engr. Fatima Abdullahi",
    date: "April 30, 2026",
    readTime: "7 min read",
    image:
      "https://raw.createusercontent.com/24c935db-c242-47e7-b577-cdacc5a164ac/",
  },
];

const categories = [
  "All",
  "Civil Engineering",
  "Structural Engineering",
  "Innovation",
  "Project Management",
];

export default function BlogPage() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredPosts = blogPosts.filter((post) => {
    const matchesCategory =
      activeCategory === "All" || post.category === activeCategory;
    const matchesSearch =
      searchQuery === "" ||
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="font-inter bg-white min-h-screen">
      {/* Top Bar */}
      <div className="border-b border-[#E5E7EB]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <a
            href="/"
            className="inline-flex items-center gap-2 text-[#6B7280] hover:text-[#111827] transition-colors font-inter text-sm"
          >
            <ArrowLeft size={16} />
            Back to Home
          </a>
        </div>
      </div>

      {/* Header */}
      <div className="bg-[#F9FAFB] py-12 lg:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="inline-flex items-center gap-2 bg-[#EFF6FF] rounded-full px-3 py-1.5 mb-4">
            <span className="w-1.5 h-1.5 bg-[#2563EB] rounded-full" />
            <span className="font-inter text-xs font-medium text-[#2563EB]">
              Insights
            </span>
          </div>
          <h1 className="font-inter font-semibold text-3xl lg:text-4xl text-[#111827] tracking-tight">
            Blog & Engineering Insights
          </h1>
          <p className="font-inter text-sm text-[#6B7280] mt-3 max-w-xl">
            Expert articles on construction, civil engineering, and project
            management from our team.
          </p>

          {/* Search */}
          <div className="relative mt-6 max-w-md">
            <Search
              size={16}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]"
            />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search articles..."
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-[#E5E7EB] rounded-lg font-inter text-sm text-[#111827] placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-blue-600 focus:ring-offset-1"
            />
          </div>
        </div>
      </div>

      {/* Filter */}
      <div className="border-b border-[#E5E7EB]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-0 overflow-x-auto">
            {categories.map((cat) => {
              const isActive = activeCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`font-inter text-sm pb-3 pt-4 px-4 whitespace-nowrap -mb-[1px] transition-colors ${
                    isActive
                      ? "text-[#111827] font-medium border-b-2 border-[#2563EB]"
                      : "text-[#6B7280] font-normal border-b-2 border-transparent hover:text-[#374151]"
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Posts Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {filteredPosts.length === 0 ? (
          <div className="text-center py-16">
            <p className="font-inter text-sm text-[#6B7280]">
              No articles found matching your criteria.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredPosts.map((post) => (
              <article
                key={post.id}
                className="bg-white rounded-xl border border-[#E5E7EB] overflow-hidden hover:border-[#D1D5DB] transition-colors group"
              >
                <div className="h-48 overflow-hidden">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <span className="inline-flex items-center bg-[#EFF6FF] rounded-full px-2.5 py-1 text-[10px] font-inter font-medium text-[#2563EB] mb-3">
                    {post.category}
                  </span>
                  <h2 className="font-inter font-semibold text-lg text-[#111827] tracking-tight">
                    {post.title}
                  </h2>
                  <p className="font-inter text-sm text-[#6B7280] mt-2 leading-relaxed line-clamp-2">
                    {post.excerpt}
                  </p>
                  <div className="flex items-center justify-between mt-5 pt-4 border-t border-[#E5E7EB]">
                    <div className="flex items-center gap-3 text-[#6B7280]">
                      <span className="inline-flex items-center gap-1 text-xs font-inter">
                        <User size={12} />
                        {post.author}
                      </span>
                      <span className="inline-flex items-center gap-1 text-xs font-inter">
                        <Clock size={12} />
                        {post.readTime}
                      </span>
                    </div>
                    <span className="font-inter text-xs text-[#9CA3AF]">
                      {post.date}
                    </span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="border-t border-[#E5E7EB] py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="font-inter text-xs text-[#9CA3AF]">
            © {new Date().getFullYear()} ANCOSOM NIGERIA LIMITED
            Engineering Ltd. All Rights Reserved.
          </p>
        </div>
      </div>
    </div>
  );
}
