export async function POST(request) {
  try {
    const body = await request.json();
    const { fullName, email, service, message } = body;

    // Validate required fields
    if (!fullName || !email || !service || !message) {
      return Response.json(
        { error: "Please fill in all required fields." },
        { status: 400 },
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return Response.json(
        { error: "Please provide a valid email address." },
        { status: 400 },
      );
    }

    // In production, you would:
    // 1. Store in database
    // 2. Send email notification
    // 3. Integrate with CRM

    // For now, log the submission and return success
    console.log("Contact form submission:", {
      fullName,
      company: body.company || "N/A",
      email,
      phone: body.phone || "N/A",
      service,
      message,
      submittedAt: new Date().toISOString(),
    });

    return Response.json({
      success: true,
      message:
        "Your message has been received. We will get back to you within 24 hours.",
    });
  } catch (err) {
    console.error("Contact form error:", err);
    return Response.json(
      { error: "An unexpected error occurred. Please try again." },
      { status: 500 },
    );
  }
}
