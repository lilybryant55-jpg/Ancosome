const testimonials = [
  {
    id: 1,
    name: "Federal Government Agency",
    position: "Client",
    company: "Nigeria Immigration Passport Office – National Headquarters",
    content:
      "ANCOSOM NIGERIA LIMITED delivered the construction of our national headquarters to a high standard of quality and professionalism. Their team demonstrated technical competence and commitment throughout the project.",
    avatar: null,
  },
  {
    id: 2,
    name: "Bauchi State Government",
    position: "Client",
    company: "Silo Complex Project – Azare & BOTO, Bauchi State",
    content:
      "The construction, installation, operations and training delivered on the Silo Complex project was a major achievement. ANCOSOM's expertise in this specialised area and their hands-on training of our personnel was outstanding.",
    avatar: null,
  },
  {
    id: 3,
    name: "Veritas University",
    position: "Client",
    company: "Chemistry Department – Laboratory Tables Construction",
    content:
      "ANCOSOM constructed and installed our laboratory tables to specification, on time and with excellent workmanship. We are very satisfied with the quality of work delivered.",
    avatar: null,
  },
  {
    id: 4,
    name: "AEDC",
    position: "Client",
    company: "AEDC Station Renovation – Minna, Niger State",
    content:
      "The renovation of our station was handled with professionalism and efficiency. ANCOSOM's team brought the right expertise and equipment to the job, completing work to the required standard.",
    avatar: null,
  },
];

export default testimonials;
