const projects = [
  {
    id: 1,
    title: "Abuja–Kaduna Expressway Rehabilitation",
    description:
      "Complete rehabilitation and expansion of a 45km stretch of the Abuja–Kaduna expressway, including drainage systems and road furniture installation.",
    category: "Road Construction",
    location: "Abuja, FCT",
    status: "Completed",
    year: "2023",
    image:
      "https://raw.createusercontent.com/64ff74a7-c4b0-4839-8293-8032472cfebf/",
  },
  {
    id: 2,
    title: "Emerald Heights Residential Complex",
    description:
      "Design and construction of a 24-unit luxury residential estate featuring modern architectural finishes, landscaping, and utility infrastructure.",
    category: "Residential Buildings",
    location: "Lekki, Lagos",
    status: "Completed",
    year: "2024",
    image:
      "https://raw.createusercontent.com/dbc2240a-113e-44a6-84ab-bf812a034f44/",
  },
  {
    id: 3,
    title: "Sterling Business Plaza",
    description:
      "A 6-storey commercial office complex with underground parking, central air conditioning, and smart building management systems.",
    category: "Commercial Buildings",
    location: "Victoria Island, Lagos",
    status: "Completed",
    year: "2023",
    image:
      "https://raw.createusercontent.com/24c935db-c242-47e7-b577-cdacc5a164ac/",
  },
  {
    id: 4,
    title: "Ogun State Flood Control Channel",
    description:
      "Construction of a 12km reinforced concrete drainage channel and culvert system to mitigate flooding in residential and commercial zones.",
    category: "Drainage Projects",
    location: "Abeokuta, Ogun State",
    status: "Completed",
    year: "2022",
    image:
      "https://raw.createusercontent.com/93ad0c85-83e9-4411-8893-ee71290ed2be/",
  },
  {
    id: 5,
    title: "Federal University Lecture Hall Complex",
    description:
      "Structural design and construction of a 2,000-capacity lecture hall complex with reinforced concrete frame and steel roof trusses.",
    category: "Structural Engineering",
    location: "Nsukka, Enugu State",
    status: "In Progress",
    year: "2025",
    image:
      "https://raw.createusercontent.com/08e51cd7-52fb-4b6b-b750-bc5b7b6ea55a/",
  },
  {
    id: 6,
    title: "Port Harcourt Industrial Warehouse",
    description:
      "Steel structure warehouse facility with 5,000 sqm floor area, loading bays, and fire suppression systems for a manufacturing client.",
    category: "Commercial Buildings",
    location: "Port Harcourt, Rivers State",
    status: "Completed",
    year: "2024",
    image:
      "https://raw.createusercontent.com/bff7d2d4-3186-4a63-b7b2-f1e3c1476a11/",
  },
];

export const projectCategories = [
  "All",
  "Road Construction",
  "Residential Buildings",
  "Commercial Buildings",
  "Drainage Projects",
  "Structural Engineering",
];

export default projects;
