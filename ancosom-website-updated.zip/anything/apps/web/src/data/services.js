import {
  HardHat,
  Building2,
  Zap,
  Droplets,
  FlaskConical,
  ClipboardList,
  Waves,
  Sun,
  Shovel,
  ShoppingCart,
} from "lucide-react";

const services = [
  {
    id: "building-construction",
    title: "Building Construction",
    icon: Building2,
    description:
      "From residential buildings to office complexes, malls, plazas and housing estates spanning several states and Abuja. We design, develop and beautify corporate and individual residential outlays including landscaping, flowering and street outlays.",
    items: [
      "Residential buildings & housing estates",
      "Office complexes, malls & plazas",
      "Plan design and drawing interpretation",
      "Cost evaluation & project development",
      "Landscaping, beautification & renovation",
    ],
  },
  {
    id: "roads-bridges",
    title: "Roads & Bridges",
    icon: HardHat,
    description:
      "ANCOSOM NIGERIA LIMITED is a design, engineering, construction and maintenance company equipped to execute major road and bridge construction projects including pedestrian bridges and flyovers across Nigeria.",
    items: [
      "Road construction & rehabilitation",
      "Bridge & flyover construction",
      "Pedestrian bridges",
      "Civil & mechanical engineering",
      "Architecture & associated fields",
    ],
  },
  {
    id: "erosion-drainage",
    title: "Erosion & Drainage Control",
    icon: Waves,
    description:
      "Comprehensive erosion and drainage control solutions to protect land, infrastructure and communities. We provide engineering designs and construction for drainage channels, dams and water management systems.",
    items: [
      "Erosion control & land stabilisation",
      "Drainage systems & channels",
      "Dam construction & maintenance",
      "Dredging & land reclamation",
      "Flood prevention infrastructure",
    ],
  },
  {
    id: "electrical-services",
    title: "Electrical Services",
    icon: Zap,
    description:
      "Full-range electrical engineering services from rural electrification to industrial installations. Our seasoned experts handle design, installation and maintenance of electrical systems all over Nigeria.",
    items: [
      "Rural electrification schemes",
      "External & internal power supply & distribution",
      "Transformer & generating set installation",
      "Electronic access control systems",
      "Solar installation & maintenance",
    ],
  },
  {
    id: "borehole-utilities",
    title: "Borehole & Utilities",
    icon: Droplets,
    description:
      "Experienced in borehole drilling and utilities design including water, sanitary, transmission and distribution systems, wastewater treatment and transport to serve Federal and State Governments and private clients.",
    items: [
      "Borehole drilling & water supply",
      "Water distribution systems",
      "Sanitary & wastewater systems",
      "Utility design & relocation",
      "In-house surveying capabilities",
    ],
  },
  {
    id: "procurement-supply",
    title: "Procurement & Supply",
    icon: ShoppingCart,
    description:
      "ANCOSOM meets the challenges of electrical, civil/building engineering, security equipment and general procurement/supplies demands, providing efficient supply and delivery solutions under a single point of contact.",
    items: [
      "Security equipment supply",
      "Hospital & medical equipment",
      "Office furniture, computers & accessories",
      "Telecommunication equipment & installation",
      "Laboratory construction & equipment",
    ],
  },
  {
    id: "project-management",
    title: "Project Management",
    icon: ClipboardList,
    description:
      "Full-cycle project management from consultancy to turnkey contracts for governments, corporate organisations and private individuals. Our team ensures successful implementation irrespective of location, at minimum budget and in the shortest time.",
    items: [
      "Turnkey project delivery",
      "Engineering consultancy",
      "Estate development",
      "Landscaping & horticultural designs",
      "Quality control & inspection",
    ],
  },
];

export default services;
