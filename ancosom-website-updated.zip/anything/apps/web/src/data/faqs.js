const faqs = [
  {
    id: 1,
    question: "What services does ANCOSOM NIGERIA LIMITED provide?",
    answer:
      "We provide a broad range of services including building construction, road and bridge construction, erosion and drainage control, borehole drilling, dredging and land reclamation, electrical services, solar installation, dam construction, procurement and general contracts, and supply and construction of laboratory and hospital equipment.",
  },
  {
    id: 2,
    question: "Who are your clients?",
    answer:
      "We work for notable private and public sector clients including the Federal Government and its agencies, State Governments, private companies, private estate owners and various individuals. We have delivered projects for clients across multiple states in Nigeria and Abuja.",
  },
  {
    id: 3,
    question: "How long has ANCOSOM been operating?",
    answer:
      "Though the company had been operating at an informal level for years, ANCOSOM NIGERIA LIMITED was formally incorporated and came into full operations in October 2012. We are registered with RC 107744. Our management team brings a wealth of experience and technical know-how accumulated over many years.",
  },
  {
    id: 4,
    question: "Can ANCOSOM handle large-scale projects?",
    answer:
      "Yes. We maintain over 50 permanent and contract staff consisting of project managers, superintendents, field engineers, administrative managers, craft supervisors and support personnel, together with a huge inventory of heavy equipment and advanced construction management systems. We can implement projects irrespective of location at minimum budget and in the shortest time.",
  },
  {
    id: 5,
    question: "Where are your offices located?",
    answer:
      "Our Head Office is at Suite 30, Danziya Plaza, Opp NNPC Mega Filling Station, Beside PA Filling Station, Central Area District, Abuja. Our Branch Office is at 5 Evans Timothy Street, Action Layout, Bwari Area Council, Abuja FCT. You can also reach us by email at ancosomenigltd@yahoo.com or by phone on 08039432214 / 08168706371.",
  },
  {
    id: 6,
    question: "How can I request a quotation?",
    answer:
      "You can request a quotation by filling out our contact form on this website, calling us directly on 08039432214 or 08168706371, or emailing us at ancosomenigltd@yahoo.com. We will schedule an initial consultation and, where required, a site assessment before providing a detailed cost estimate tailored to your project.",
  },
];

export default faqs;
