import {
  Landmark,
  Building2,
  GraduationCap,
  Church,
  Factory,
  Store,
  User,
} from "lucide-react";

const industries = [
  {
    icon: Landmark,
    label: "Government Agencies",
    desc: "Federal, state, and local government infrastructure projects.",
  },
  {
    icon: Building2,
    label: "Real Estate Developers",
    desc: "Residential and commercial property development.",
  },
  {
    icon: GraduationCap,
    label: "Educational Institutions",
    desc: "Schools, universities, and research facilities.",
  },
  {
    icon: Church,
    label: "Religious Organizations",
    desc: "Places of worship and community buildings.",
  },
  {
    icon: Factory,
    label: "Manufacturing Industries",
    desc: "Industrial facilities, warehouses, and factory structures.",
  },
  {
    icon: Store,
    label: "Commercial Businesses",
    desc: "Office complexes, retail spaces, and hospitality venues.",
  },
  {
    icon: User,
    label: "Private Clients",
    desc: "Custom homes, private estates, and personal projects.",
  },
];

export default function IndustriesSection() {
  return (
    <section className="bg-[#F9FAFB] py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 bg-[#EFF6FF] rounded-full px-3 py-1.5 mb-4">
            <span className="w-1.5 h-1.5 bg-[#2563EB] rounded-full" />
            <span className="font-inter text-xs font-medium text-[#2563EB]">
              Sectors
            </span>
          </div>
          <h2 className="font-inter font-semibold text-2xl lg:text-3xl text-[#111827] tracking-tight">
            Industries We Serve
          </h2>
          <p className="font-inter text-sm text-[#6B7280] mt-3">
            We partner with diverse sectors to deliver infrastructure that
            drives growth and development.
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {industries.map((ind) => (
            <div
              key={ind.label}
              className="bg-white rounded-xl border border-[#E5E7EB] p-5 hover:border-[#D1D5DB] transition-colors text-center"
            >
              <div className="w-12 h-12 rounded-xl bg-[#EFF6FF] flex items-center justify-center mx-auto mb-3">
                <ind.icon size={22} className="text-[#2563EB]" />
              </div>
              <h3 className="font-inter font-semibold text-sm text-[#111827]">
                {ind.label}
              </h3>
              <p className="font-inter text-xs text-[#6B7280] mt-1 leading-relaxed">
                {ind.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
