import { useState } from "react";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";
import testimonials from "../data/testimonials";

export default function TestimonialsSection() {
  const [active, setActive] = useState(0);

  const next = () => setActive((prev) => (prev + 1) % testimonials.length);
  const prev = () =>
    setActive((prev) => (prev - 1 + testimonials.length) % testimonials.length);

  const t = testimonials[active];

  return (
    <section id="testimonials" className="bg-white py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 bg-[#EFF6FF] rounded-full px-3 py-1.5 mb-4">
            <span className="w-1.5 h-1.5 bg-[#2563EB] rounded-full" />
            <span className="font-inter text-xs font-medium text-[#2563EB]">
              Client Feedback
            </span>
          </div>
          <h2 className="font-inter font-semibold text-2xl lg:text-3xl text-[#111827] tracking-tight">
            What Our Clients Say
          </h2>
          <p className="font-inter text-sm text-[#6B7280] mt-3">
            Trusted by government agencies, developers, and private clients
            across Nigeria.
          </p>
        </div>

        {/* Testimonial Card */}
        <div className="max-w-3xl mx-auto">
          <div className="bg-white rounded-xl border border-[#E5E7EB] p-8 lg:p-10 relative">
            <div className="absolute top-6 right-6">
              <Quote size={32} className="text-[#E5E7EB]" />
            </div>
            <p className="font-inter text-base lg:text-lg text-[#374151] leading-relaxed italic">
              "{t.content}"
            </p>
            <div className="flex items-center gap-4 mt-6 pt-6 border-t border-[#E5E7EB]">
              {/* Avatar */}
              <div className="w-12 h-12 rounded-full bg-[#2563EB] flex items-center justify-center flex-shrink-0">
                <span className="font-inter font-semibold text-white text-sm">
                  {t.name
                    .split(" ")
                    .map((n) => n[0])
                    .slice(0, 2)
                    .join("")}
                </span>
              </div>
              <div>
                <h4 className="font-inter font-semibold text-sm text-[#111827]">
                  {t.name}
                </h4>
                <p className="font-inter text-xs text-[#6B7280]">
                  {t.position}, {t.company}
                </p>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-center gap-4 mt-6">
            <button
              onClick={prev}
              className="w-10 h-10 rounded-full border border-[#E5E7EB] flex items-center justify-center text-[#6B7280] hover:text-[#111827] hover:border-[#D1D5DB] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
              aria-label="Previous testimonial"
            >
              <ChevronLeft size={18} />
            </button>
            <div className="flex items-center gap-2">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setActive(i)}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    i === active ? "bg-[#2563EB]" : "bg-[#E5E7EB]"
                  }`}
                  aria-label={`Go to testimonial ${i + 1}`}
                />
              ))}
            </div>
            <button
              onClick={next}
              className="w-10 h-10 rounded-full border border-[#E5E7EB] flex items-center justify-center text-[#6B7280] hover:text-[#111827] hover:border-[#D1D5DB] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
              aria-label="Next testimonial"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
