import {
  Award,
  ShieldCheck,
  Clock,
  HardHat,
  UserCheck,
  Lightbulb,
} from "lucide-react";

const reasons = [
  {
    icon: Award,
    title: "Experienced Professionals",
    description:
      "Qualified engineers and construction specialists with deep industry expertise.",
  },
  {
    icon: ShieldCheck,
    title: "Quality Assurance",
    description:
      "Strict adherence to engineering standards and best practices on every project.",
  },
  {
    icon: Clock,
    title: "Timely Delivery",
    description:
      "Projects completed efficiently and professionally, on schedule and within budget.",
  },
  {
    icon: HardHat,
    title: "Safety First",
    description:
      "Unwavering commitment to safe work environments and regulatory compliance.",
  },
  {
    icon: UserCheck,
    title: "Client-Focused",
    description:
      "Solutions tailored to client objectives, with transparent communication throughout.",
  },
  {
    icon: Lightbulb,
    title: "Innovation",
    description:
      "Application of modern engineering practices and technologies to every challenge.",
  },
];

export default function WhyChooseUs() {
  return (
    <section className="bg-white py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 bg-[#EFF6FF] rounded-full px-3 py-1.5 mb-4">
            <span className="w-1.5 h-1.5 bg-[#2563EB] rounded-full" />
            <span className="font-inter text-xs font-medium text-[#2563EB]">
              Why ANCOSOM
            </span>
          </div>
          <h2 className="font-inter font-semibold text-2xl lg:text-3xl text-[#111827] tracking-tight">
            Why Choose Us
          </h2>
          <p className="font-inter text-sm text-[#6B7280] mt-3">
            We combine technical excellence, industry experience, and client
            commitment to deliver projects that stand the test of time.
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {reasons.map((r) => (
            <div
              key={r.title}
              className="bg-white rounded-xl border border-[#E5E7EB] p-6 hover:border-[#D1D5DB] transition-colors"
            >
              <div className="w-10 h-10 rounded-lg bg-[#EFF6FF] flex items-center justify-center mb-4">
                <r.icon size={20} className="text-[#2563EB]" />
              </div>
              <h3 className="font-inter font-semibold text-base text-[#111827]">
                {r.title}
              </h3>
              <p className="font-inter text-sm text-[#6B7280] mt-1.5 leading-relaxed">
                {r.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
