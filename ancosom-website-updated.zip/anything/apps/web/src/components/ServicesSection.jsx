import { useState } from "react";
import { ArrowRight } from "lucide-react";
import services from "../data/services";

export default function ServicesSection() {
  const [activeId, setActiveId] = useState(services[0].id);
  const activeService = services.find((s) => s.id === activeId);

  return (
    <section id="services" className="bg-[#F9FAFB] py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 bg-[#EFF6FF] rounded-full px-3 py-1.5 mb-4">
            <span className="w-1.5 h-1.5 bg-[#2563EB] rounded-full" />
            <span className="font-inter text-xs font-medium text-[#2563EB]">
              Our Expertise
            </span>
          </div>
          <h2 className="font-inter font-semibold text-2xl lg:text-3xl text-[#111827] tracking-tight">
            Comprehensive Engineering Services
          </h2>
          <p className="font-inter text-sm text-[#6B7280] mt-3">
            From concept to completion, we deliver integrated engineering and
            construction solutions tailored to your project requirements.
          </p>
        </div>

        {/* Tab Nav */}
        <div className="border-b border-[#E5E7EB] mb-8 overflow-x-auto">
          <div className="flex min-w-max">
            {services.map((s) => {
              const isActive = activeId === s.id;
              return (
                <button
                  key={s.id}
                  onClick={() => setActiveId(s.id)}
                  className={`font-inter text-sm pb-3 px-4 -mb-[1px] transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 ${
                    isActive
                      ? "text-[#111827] font-medium border-b-2 border-[#2563EB]"
                      : "text-[#6B7280] font-normal border-b-2 border-transparent hover:text-[#374151]"
                  }`}
                >
                  {s.title}
                </button>
              );
            })}
          </div>
        </div>

        {/* Active Service Detail */}
        {activeService && (
          <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 lg:p-8">
            <div className="flex flex-col lg:flex-row gap-8">
              <div className="lg:w-1/2">
                <div className="w-12 h-12 rounded-xl bg-[#EFF6FF] flex items-center justify-center mb-4">
                  <activeService.icon size={24} className="text-[#2563EB]" />
                </div>
                <h3 className="font-inter font-semibold text-xl text-[#111827] tracking-tight">
                  {activeService.title}
                </h3>
                <p className="font-inter text-sm text-[#6B7280] mt-2 leading-relaxed">
                  {activeService.description}
                </p>
                <button
                  onClick={() => {
                    const el = document.getElementById("contact");
                    if (el) el.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="inline-flex items-center gap-2 bg-[#2563EB] text-white font-inter font-medium text-sm px-5 py-2.5 rounded-lg hover:bg-[#1d4ed8] transition-colors mt-6 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
                >
                  Request This Service
                  <ArrowRight size={14} />
                </button>
              </div>
              <div className="lg:w-1/2">
                <h4 className="font-inter font-semibold text-sm text-[#111827] mb-3">
                  What We Deliver
                </h4>
                <ul className="space-y-2.5">
                  {activeService.items.map((item) => (
                    <li
                      key={item}
                      className="flex items-center gap-2 font-inter text-sm text-[#4B5563] py-1"
                    >
                      <span className="text-[#9CA3AF] mr-2">-</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* Service Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 mt-8">
          {services.map((s) => {
            const isActive = activeId === s.id;
            return (
              <button
                key={s.id}
                onClick={() => setActiveId(s.id)}
                className={`text-left rounded-xl border p-4 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 ${
                  isActive
                    ? "border-[#2563EB] bg-[#EFF6FF]"
                    : "border-[#E5E7EB] bg-white hover:border-[#D1D5DB]"
                }`}
              >
                <s.icon
                  size={20}
                  className={isActive ? "text-[#2563EB]" : "text-[#6B7280]"}
                />
                <p
                  className={`font-inter text-sm mt-2 ${
                    isActive
                      ? "text-[#2563EB] font-medium"
                      : "text-[#374151] font-normal"
                  }`}
                >
                  {s.title}
                </p>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
