import { MessageCircle } from "lucide-react";

export default function WhatsAppButton() {
  return (
    <a
      href="https://wa.me/2341234567890?text=Hello%2C%20I%20would%20like%20to%20inquire%20about%20your%20engineering%20services."
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat on WhatsApp"
      className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-[#25D366] rounded-full flex items-center justify-center text-white hover:bg-[#1ebe57] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-green-600 focus-visible:ring-offset-2"
      style={{ boxShadow: "0 4px 12px rgba(37, 211, 102, 0.4)" }}
    >
      <MessageCircle size={26} fill="white" />
    </a>
  );
}
