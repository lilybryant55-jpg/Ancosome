import {
  ArrowRight,
  ChevronDown,
  Award,
  MapPin,
  Users,
  Briefcase,
} from "lucide-react";

const stats = [
  { icon: Briefcase, value: "50+", label: "Projects Delivered" },
  { icon: Award, value: "2012", label: "Incorporated (RC 107744)" },
  { icon: Users, value: "50+", label: "Permanent & Contract Staff" },
  { icon: MapPin, value: "Nationwide", label: "Coverage Across Nigeria" },
];

export default function HeroSection({ heroImage }) {
  const scrollTo = (id) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <section id="hero" className="relative min-h-screen flex flex-col">
      {/* Background */}
      <div className="absolute inset-0">
        {heroImage ? (
          <img
            src={heroImage}
            alt="Construction project"
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-[#0f172a]" />
        )}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0f172a]/80 via-[#0f172a]/60 to-[#0f172a]/90" />
      </div>

      {/* Blueprint Pattern Overlay */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />

      {/* Content */}
      <div className="relative z-10 flex-1 flex items-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12 lg:pt-32">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-white/10 border border-white/20 rounded-full px-4 py-1.5 mb-6">
            <span className="w-1.5 h-1.5 bg-[#2563EB] rounded-full" />
            <span className="font-inter text-xs font-medium text-white/80">
              Building & Strengthening Nigeria's Capacity
            </span>
          </div>

          <h1 className="font-inter font-semibold text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-white tracking-tight leading-tight max-w-3xl">
            Engineering Excellence.{" "}
            <span className="text-[#2563EB]">Nationwide Delivery.</span>
          </h1>

          <p className="font-inter text-base sm:text-lg text-white/70 mt-5 max-w-2xl leading-relaxed">
            ANCOSOM NIGERIA LIMITED — delivering civil engineering, building
            construction, borehole drilling, electrical services, erosion
            control and general procurement across Nigeria since 2012.
          </p>

          <div className="flex flex-col sm:flex-row gap-3 mt-8">
            <button
              onClick={() => scrollTo("contact")}
              className="inline-flex items-center justify-center gap-2 bg-[#2563EB] text-white font-inter font-medium text-sm px-6 py-3 rounded-lg hover:bg-[#1d4ed8] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
            >
              Request Consultation
              <ArrowRight size={16} />
            </button>
            <button
              onClick={() => scrollTo("services")}
              className="inline-flex items-center justify-center gap-2 bg-white/10 border border-white/20 text-white font-inter font-medium text-sm px-6 py-3 rounded-lg hover:bg-white/20 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
            >
              View Services
            </button>
          </div>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="relative z-10 border-t border-white/10 bg-white/5 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 divide-x divide-white/10">
            {stats.map((stat) => (
              <div
                key={stat.label}
                className="flex items-center gap-3 py-6 lg:py-8 px-4 lg:px-6 first:pl-0"
              >
                <div className="w-10 h-10 rounded-lg bg-[#2563EB]/20 flex items-center justify-center flex-shrink-0">
                  <stat.icon size={18} className="text-[#2563EB]" />
                </div>
                <div>
                  <div className="font-inter font-semibold text-xl lg:text-2xl text-white tracking-tight">
                    {stat.value}
                  </div>
                  <div className="font-inter text-xs text-white/50">
                    {stat.label}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <button
        onClick={() => scrollTo("about")}
        className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10 text-white/40 hover:text-white/70 transition-colors hidden lg:block"
        aria-label="Scroll down"
      >
        <ChevronDown size={28} />
      </button>
    </section>
  );
}
