import {
  ClipboardCheck,
  PenTool,
  Calculator,
  Hammer,
  SearchCheck,
  PackageCheck,
} from "lucide-react";

const steps = [
  {
    num: "01",
    icon: ClipboardCheck,
    title: "Consultation & Site Assessment",
    description:
      "We begin with a thorough understanding of your requirements and a detailed on-site evaluation.",
  },
  {
    num: "02",
    icon: PenTool,
    title: "Planning & Design",
    description:
      "Our engineers develop comprehensive plans, drawings, and specifications for your project.",
  },
  {
    num: "03",
    icon: Calculator,
    title: "Engineering Analysis",
    description:
      "Rigorous structural and civil engineering analysis ensures safety, compliance, and cost efficiency.",
  },
  {
    num: "04",
    icon: Hammer,
    title: "Construction & Execution",
    description:
      "Expert construction teams deliver your project with precision, quality materials, and safety protocols.",
  },
  {
    num: "05",
    icon: SearchCheck,
    title: "Quality Inspection",
    description:
      "Comprehensive inspections and testing at every stage to meet engineering standards.",
  },
  {
    num: "06",
    icon: PackageCheck,
    title: "Project Delivery",
    description:
      "Final handover with full documentation, warranties, and post-completion support.",
  },
];

export default function ProcessSection() {
  return (
    <section id="process" className="bg-white py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 bg-[#EFF6FF] rounded-full px-3 py-1.5 mb-4">
            <span className="w-1.5 h-1.5 bg-[#2563EB] rounded-full" />
            <span className="font-inter text-xs font-medium text-[#2563EB]">
              How We Work
            </span>
          </div>
          <h2 className="font-inter font-semibold text-2xl lg:text-3xl text-[#111827] tracking-tight">
            Our Construction Process
          </h2>
          <p className="font-inter text-sm text-[#6B7280] mt-3">
            A structured, transparent approach from initial consultation to
            project delivery.
          </p>
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Vertical Line (desktop) */}
          <div className="hidden lg:block absolute left-1/2 top-0 bottom-0 w-px bg-[#E5E7EB] -translate-x-1/2" />

          <div className="space-y-6 lg:space-y-0">
            {steps.map((step, idx) => {
              const isLeft = idx % 2 === 0;
              return (
                <div
                  key={step.num}
                  className="relative lg:flex lg:items-center lg:min-h-[140px]"
                >
                  {/* Desktop layout */}
                  <div
                    className={`hidden lg:flex items-center w-full ${
                      isLeft ? "flex-row" : "flex-row-reverse"
                    }`}
                  >
                    {/* Content Card */}
                    <div className="w-[calc(50%-32px)]">
                      <div
                        className={`bg-white rounded-xl border border-[#E5E7EB] p-5 hover:border-[#D1D5DB] transition-colors ${
                          isLeft ? "text-right" : "text-left"
                        }`}
                      >
                        <div
                          className={`flex items-center gap-3 ${
                            isLeft ? "justify-end" : "justify-start"
                          }`}
                        >
                          {isLeft && (
                            <h3 className="font-inter font-semibold text-base text-[#111827]">
                              {step.title}
                            </h3>
                          )}
                          <div className="w-10 h-10 rounded-lg bg-[#EFF6FF] flex items-center justify-center flex-shrink-0">
                            <step.icon size={18} className="text-[#2563EB]" />
                          </div>
                          {!isLeft && (
                            <h3 className="font-inter font-semibold text-base text-[#111827]">
                              {step.title}
                            </h3>
                          )}
                        </div>
                        <p className="font-inter text-sm text-[#6B7280] mt-2 leading-relaxed">
                          {step.description}
                        </p>
                      </div>
                    </div>

                    {/* Center Node */}
                    <div className="w-16 flex items-center justify-center relative z-10">
                      <div className="w-10 h-10 rounded-full bg-[#2563EB] flex items-center justify-center">
                        <span className="font-inter text-xs font-semibold text-white">
                          {step.num}
                        </span>
                      </div>
                    </div>

                    {/* Spacer */}
                    <div className="w-[calc(50%-32px)]" />
                  </div>

                  {/* Mobile layout */}
                  <div className="lg:hidden flex gap-4">
                    <div className="flex flex-col items-center">
                      <div className="w-10 h-10 rounded-full bg-[#2563EB] flex items-center justify-center flex-shrink-0">
                        <span className="font-inter text-xs font-semibold text-white">
                          {step.num}
                        </span>
                      </div>
                      {idx < steps.length - 1 && (
                        <div className="w-px flex-1 bg-[#E5E7EB] mt-2" />
                      )}
                    </div>
                    <div className="bg-white rounded-xl border border-[#E5E7EB] p-4 mb-2 flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <step.icon size={16} className="text-[#2563EB]" />
                        <h3 className="font-inter font-semibold text-sm text-[#111827]">
                          {step.title}
                        </h3>
                      </div>
                      <p className="font-inter text-sm text-[#6B7280] leading-relaxed">
                        {step.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
