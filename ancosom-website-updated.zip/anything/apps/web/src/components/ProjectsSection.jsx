import { useState } from "react";
import { MapPin, ExternalLink } from "lucide-react";
import projects, { projectCategories } from "../data/projects";

export default function ProjectsSection({ projectImages }) {
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredProjects =
    activeCategory === "All"
      ? projects
      : projects.filter((p) => p.category === activeCategory);

  return (
    <section id="projects" className="bg-[#F9FAFB] py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 bg-[#EFF6FF] rounded-full px-3 py-1.5 mb-4">
            <span className="w-1.5 h-1.5 bg-[#2563EB] rounded-full" />
            <span className="font-inter text-xs font-medium text-[#2563EB]">
              Our Portfolio
            </span>
          </div>
          <h2 className="font-inter font-semibold text-2xl lg:text-3xl text-[#111827] tracking-tight">
            Featured Projects
          </h2>
          <p className="font-inter text-sm text-[#6B7280] mt-3">
            A showcase of our engineering and construction projects across
            Nigeria.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {projectCategories.map((cat) => {
            const isActive = activeCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`font-inter text-xs font-medium px-4 py-2 rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 ${
                  isActive
                    ? "bg-[#2563EB] text-white"
                    : "bg-white border border-[#E5E7EB] text-[#374151] hover:border-[#D1D5DB]"
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>

        {/* Project Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredProjects.map((project, idx) => {
            const img = projectImages?.[idx] || project.image;
            return (
              <div
                key={project.id}
                className="group bg-white rounded-xl border border-[#E5E7EB] overflow-hidden hover:border-[#D1D5DB] transition-colors"
              >
                {/* Image */}
                <div className="relative h-48 overflow-hidden">
                  {img ? (
                    <img
                      src={img}
                      alt={project.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-[#F9FAFB] flex items-center justify-center">
                      <span className="font-inter text-xs text-[#6B7280]">
                        Project Image
                      </span>
                    </div>
                  )}
                  {/* Status Badge */}
                  <div className="absolute top-3 left-3">
                    <span className="inline-flex items-center gap-1.5 bg-white border border-[#E5E7EB] rounded-full px-2.5 py-1 text-xs font-inter text-[#374151]">
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          project.status === "Completed"
                            ? "bg-green-500"
                            : "bg-orange-500"
                        }`}
                      />
                      {project.status}
                    </span>
                  </div>
                  {/* Category Badge */}
                  <div className="absolute top-3 right-3">
                    <span className="inline-flex items-center bg-[#0f172a]/70 rounded-full px-2.5 py-1 text-[10px] font-inter text-white">
                      {project.category}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5">
                  <h3 className="font-inter font-semibold text-base text-[#111827]">
                    {project.title}
                  </h3>
                  <p className="font-inter text-sm text-[#6B7280] mt-1.5 leading-relaxed line-clamp-2">
                    {project.description}
                  </p>
                  <div className="flex items-center justify-between mt-4 pt-4 border-t border-[#E5E7EB]">
                    <div className="flex items-center gap-1.5 text-[#6B7280]">
                      <MapPin size={13} />
                      <span className="font-inter text-xs">
                        {project.location}
                      </span>
                    </div>
                    <span className="font-inter text-xs text-[#6B7280]">
                      {project.year}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
