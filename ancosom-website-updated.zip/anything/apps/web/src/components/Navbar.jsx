import { useState, useEffect } from "react";
import { Menu, X, Phone } from "lucide-react";

const navLinks = [
  { label: "Home", href: "#hero" },
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Projects", href: "#projects" },
  { label: "Process", href: "#process" },
  { label: "Testimonials", href: "#testimonials" },
  { label: "FAQ", href: "#faq" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar({ logoUrl }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("hero");

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);

      const sections = navLinks.map((l) => l.href.replace("#", ""));
      let current = "hero";
      for (const id of sections) {
        const el = document.getElementById(id);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 120) current = id;
        }
      }
      setActiveSection(current);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollTo = (href) => {
    const el = document.getElementById(href.replace("#", ""));
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
    setMobileOpen(false);
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-200 ${
        scrolled ? "bg-white border-b border-[#E5E7EB]" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <button
            onClick={() => scrollTo("#hero")}
            className="flex items-center gap-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 rounded-sm"
          >
            {logoUrl ? (
              <img
                src={logoUrl}
                alt="ANCOSOM Nigeria"
                className="h-8 w-8 object-contain"
              />
            ) : (
              <div className="h-8 w-8 bg-[#2563EB] rounded-sm flex items-center justify-center">
                <span className="text-white font-inter font-semibold text-sm">
                  A
                </span>
              </div>
            )}
            <div className="flex flex-col">
              <span
                className={`font-inter font-semibold text-sm tracking-tight leading-none ${
                  scrolled ? "text-[#111827]" : "text-white"
                }`}
              >
                ANCOSOM NIGERIA LIMITED
              </span>
              <span
                className={`font-inter text-[10px] tracking-wide leading-none mt-0.5 ${
                  scrolled ? "text-[#6B7280]" : "text-white/70"
                }`}
              >
                ENGINEERS & BUILDERS · RC 107744
              </span>
            </div>
          </button>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => {
              const isActive = activeSection === link.href.replace("#", "");
              return (
                <button
                  key={link.href}
                  onClick={() => scrollTo(link.href)}
                  className={`px-3 py-2 text-sm font-inter font-medium rounded-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 ${
                    isActive
                      ? scrolled
                        ? "text-[#2563EB]"
                        : "text-white"
                      : scrolled
                        ? "text-[#6B7280] hover:text-[#111827]"
                        : "text-white/70 hover:text-white"
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </div>

          {/* Desktop CTA */}
          <div className="hidden lg:flex items-center gap-3">
            <a
              href="tel:+2341234567890"
              className={`inline-flex items-center gap-1.5 text-sm font-inter font-medium px-3 py-1.5 rounded-full border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 ${
                scrolled
                  ? "border-[#E5E7EB] text-[#111827] hover:bg-[#F9FAFB]"
                  : "border-white/30 text-white hover:bg-white/10"
              }`}
            >
              <Phone size={14} />
              <span>+234 123 456 7890</span>
            </a>
            <button
              onClick={() => scrollTo("#contact")}
              className="bg-[#2563EB] text-white text-sm font-inter font-medium px-5 py-2 rounded-lg hover:bg-[#1d4ed8] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
            >
              Get a Quote
            </button>
          </div>

          {/* Mobile Toggle */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className={`lg:hidden p-2 rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 ${
              scrolled ? "text-[#111827]" : "text-white"
            }`}
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="lg:hidden bg-white border-t border-[#E5E7EB]">
          <div className="px-4 py-4 space-y-1">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => scrollTo(link.href)}
                className="block w-full text-left px-4 py-2.5 text-sm font-inter text-[#111827] hover:bg-[#F9FAFB] rounded-lg transition-colors"
              >
                {link.label}
              </button>
            ))}
            <div className="pt-3 border-t border-[#E5E7EB] mt-3">
              <button
                onClick={() => scrollTo("#contact")}
                className="w-full bg-[#2563EB] text-white text-sm font-inter font-medium px-5 py-2.5 rounded-lg hover:bg-[#1d4ed8] transition-colors"
              >
                Get a Quote
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
