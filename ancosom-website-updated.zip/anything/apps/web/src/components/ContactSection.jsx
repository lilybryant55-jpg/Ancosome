import { useState } from "react";
import { Send, MapPin, Phone, Mail, Clock, Download } from "lucide-react";

const serviceOptions = [
  "Building Construction",
  "Roads & Bridges",
  "Erosion & Drainage Control",
  "Electrical Services",
  "Borehole Drilling",
  "Dredging & Land Reclamation",
  "Solar Installation & Maintenance",
  "Dam Construction & Maintenance",
  "Procurement & General Contracts",
  "Laboratory & Hospital Equipment",
  "Project Management & Consultancy",
  "Other",
];

export default function ContactSection() {
  const [form, setForm] = useState({
    fullName: "",
    company: "",
    email: "",
    phone: "",
    service: "",
    message: "",
  });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!response.ok) {
        throw new Error(`Submission failed [${response.status}]`);
      }
      setSuccess(true);
      setForm({
        fullName: "",
        company: "",
        email: "",
        phone: "",
        service: "",
        message: "",
      });
    } catch (err) {
      console.error(err);
      setError(
        "Something went wrong. Please try again or contact us directly.",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const inputClasses =
    "w-full px-4 py-2.5 bg-white border border-[#E5E7EB] rounded-lg font-inter text-sm text-[#111827] placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-blue-600 focus:ring-offset-1 transition-colors";

  return (
    <section id="contact" className="bg-white py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 bg-[#EFF6FF] rounded-full px-3 py-1.5 mb-4">
            <span className="w-1.5 h-1.5 bg-[#2563EB] rounded-full" />
            <span className="font-inter text-xs font-medium text-[#2563EB]">
              Get In Touch
            </span>
          </div>
          <h2 className="font-inter font-semibold text-2xl lg:text-3xl text-[#111827] tracking-tight">
            Request a Consultation
          </h2>
          <p className="font-inter text-sm text-[#6B7280] mt-3">
            Let's discuss your project. Fill out the form below and our team
            will get back to you within 24 hours.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">
          {/* Form */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl border border-[#E5E7EB] p-6 lg:p-8">
              {success ? (
                <div className="text-center py-12">
                  <div className="w-14 h-14 rounded-full bg-green-50 flex items-center justify-center mx-auto mb-4">
                    <Send size={22} className="text-green-600" />
                  </div>
                  <h3 className="font-inter font-semibold text-lg text-[#111827]">
                    Message Sent Successfully
                  </h3>
                  <p className="font-inter text-sm text-[#6B7280] mt-2">
                    Thank you for reaching out. Our team will respond within 24
                    business hours.
                  </p>
                  <button
                    onClick={() => setSuccess(false)}
                    className="mt-6 font-inter text-sm text-[#2563EB] font-medium hover:underline"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-inter text-xs font-medium text-[#374151] mb-1.5">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        name="fullName"
                        required
                        value={form.fullName}
                        onChange={handleChange}
                        placeholder="Enter your full name"
                        className={inputClasses}
                      />
                    </div>
                    <div>
                      <label className="block font-inter text-xs font-medium text-[#374151] mb-1.5">
                        Company
                      </label>
                      <input
                        type="text"
                        name="company"
                        value={form.company}
                        onChange={handleChange}
                        placeholder="Company or organization"
                        className={inputClasses}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-inter text-xs font-medium text-[#374151] mb-1.5">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        name="email"
                        required
                        value={form.email}
                        onChange={handleChange}
                        placeholder="you@example.com"
                        className={inputClasses}
                      />
                    </div>
                    <div>
                      <label className="block font-inter text-xs font-medium text-[#374151] mb-1.5">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={form.phone}
                        onChange={handleChange}
                        placeholder="+234 xxx xxx xxxx"
                        className={inputClasses}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-inter text-xs font-medium text-[#374151] mb-1.5">
                      Service Required *
                    </label>
                    <select
                      name="service"
                      required
                      value={form.service}
                      onChange={handleChange}
                      className={inputClasses}
                    >
                      <option value="">Select a service</option>
                      {serviceOptions.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block font-inter text-xs font-medium text-[#374151] mb-1.5">
                      Project Description *
                    </label>
                    <textarea
                      name="message"
                      required
                      rows={4}
                      value={form.message}
                      onChange={handleChange}
                      placeholder="Tell us about your project requirements, timeline, and any specific details..."
                      className={inputClasses}
                      style={{ resize: "vertical" }}
                    />
                  </div>

                  {error && (
                    <p className="font-inter text-sm text-red-600">{error}</p>
                  )}

                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#2563EB] text-white font-inter font-medium text-sm px-6 py-3 rounded-lg hover:bg-[#1d4ed8] transition-colors disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
                  >
                    {submitting ? "Sending..." : "Submit Request"}
                    <Send size={14} />
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Contact Info Sidebar */}
          <div className="space-y-5">
            <div className="bg-white rounded-xl border border-[#E5E7EB] p-5">
              <h3 className="font-inter font-semibold text-sm text-[#111827] mb-4">
                Contact Information
              </h3>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-[#EFF6FF] flex items-center justify-center flex-shrink-0">
                    <MapPin size={16} className="text-[#2563EB]" />
                  </div>
                  <div>
                    <p className="font-inter text-xs font-medium text-[#374151]">
                      Address
                    </p>
                    <p className="font-inter text-xs text-[#6B7280] mt-0.5">
                      Suite 30, Danziya Plaza, Opp NNPC Mega Filling Station,
                      <br />
                      Central Area District, Abuja
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-[#EFF6FF] flex items-center justify-center flex-shrink-0">
                    <Phone size={16} className="text-[#2563EB]" />
                  </div>
                  <div>
                    <p className="font-inter text-xs font-medium text-[#374151]">
                      Phone
                    </p>
                    <p className="font-inter text-xs text-[#6B7280] mt-0.5">
                      08039432214 / 08168706371
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-[#EFF6FF] flex items-center justify-center flex-shrink-0">
                    <Mail size={16} className="text-[#2563EB]" />
                  </div>
                  <div>
                    <p className="font-inter text-xs font-medium text-[#374151]">
                      Email
                    </p>
                    <p className="font-inter text-xs text-[#6B7280] mt-0.5">
                      ancosomenigltd@yahoo.com
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-[#EFF6FF] flex items-center justify-center flex-shrink-0">
                    <Clock size={16} className="text-[#2563EB]" />
                  </div>
                  <div>
                    <p className="font-inter text-xs font-medium text-[#374151]">
                      Business Hours
                    </p>
                    <p className="font-inter text-xs text-[#6B7280] mt-0.5">
                      Mon – Fri: 8:00 AM – 5:00 PM
                      <br />
                      Sat: 9:00 AM – 1:00 PM
                    </p>
                  </div>
                </li>
              </ul>
            </div>

            {/* Company Profile Download */}
            <div className="bg-[#0f172a] rounded-xl p-5 text-white">
              <h3 className="font-inter font-semibold text-sm">
                Company Profile
              </h3>
              <p className="font-inter text-xs text-white/60 mt-1.5">
                Download our company profile for a comprehensive overview of our
                capabilities.
              </p>
              <button className="mt-4 w-full inline-flex items-center justify-center gap-2 bg-white/10 border border-white/20 text-white font-inter font-medium text-xs px-4 py-2.5 rounded-lg hover:bg-white/20 transition-colors">
                <Download size={14} />
                Download PDF
              </button>
            </div>

            {/* Map Placeholder */}
            <div className="bg-white rounded-xl border border-[#E5E7EB] overflow-hidden">
              <div className="h-48 bg-[#F9FAFB] flex items-center justify-center">
                <div className="text-center">
                  <MapPin size={24} className="text-[#6B7280] mx-auto mb-2" />
                  <p className="font-inter text-xs text-[#6B7280]">
                    Central Area District, Abuja, Nigeria
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
