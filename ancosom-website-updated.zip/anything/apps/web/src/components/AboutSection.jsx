import {
  Target,
  Eye,
  Shield,
  Star,
  Lightbulb,
  HeartHandshake,
  Leaf,
  Users,
} from "lucide-react";

const coreValues = [
  { icon: Shield, label: "Integrity" },
  { icon: Star, label: "Excellence" },
  { icon: Lightbulb, label: "Innovation" },
  { icon: HeartHandshake, label: "Safety" },
  { icon: Leaf, label: "Sustainability" },
  { icon: Users, label: "Client Satisfaction" },
];

export default function AboutSection({ teamImage }) {
  return (
    <section id="about" className="bg-white py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row gap-12 lg:gap-16">
          {/* Left - Image */}
          <div className="lg:w-1/2">
            <div className="relative">
              <div className="rounded-xl border border-[#E5E7EB] overflow-hidden">
                {teamImage ? (
                  <img
                    src={teamImage}
                    alt="ANCOSOM Nigeria team"
                    className="w-full h-[360px] lg:h-[480px] object-cover"
                  />
                ) : (
                  <div className="w-full h-[360px] lg:h-[480px] bg-[#F9FAFB] flex items-center justify-center">
                    <span className="font-inter text-sm text-[#6B7280]">
                      Team Photo
                    </span>
                  </div>
                )}
              </div>
              {/* Badge */}
              <div className="absolute -bottom-4 -right-4 bg-[#2563EB] text-white rounded-xl p-4 lg:p-5">
                <div className="font-inter font-semibold text-2xl lg:text-3xl tracking-tight">
                  2012
                </div>
                <div className="font-inter text-xs text-white/80">
                  Incorporated
                  <br />
                  RC 107744
                </div>
              </div>
            </div>
          </div>

          {/* Right - Content */}
          <div className="lg:w-1/2">
            <div className="inline-flex items-center gap-2 bg-[#EFF6FF] rounded-full px-3 py-1.5 mb-4">
              <span className="w-1.5 h-1.5 bg-[#2563EB] rounded-full" />
              <span className="font-inter text-xs font-medium text-[#2563EB]">
                About Us
              </span>
            </div>

            <h2 className="font-inter font-semibold text-2xl lg:text-3xl text-[#111827] tracking-tight">
              Who We Are
            </h2>

            <p className="font-inter text-sm text-[#6B7280] mt-4 leading-relaxed">
              ANCOSOM NIGERIA LIMITED (RC 107744) is an engineering and
              construction company that came into full operations in October
              2012. We provide a broad-based construction engineering and
              related services that challenge the present foreign dominance of
              the construction engineering industry by delivering equivalent or
              better services.
            </p>
            <p className="font-inter text-sm text-[#6B7280] mt-3 leading-relaxed">
              We are a team of uncommon professionals with a common aim —
              rendering competent and quality services to our esteemed clients.
              We maintain over 50 permanent and contract staff including project
              managers, field engineers, craft supervisors and support
              personnel, backed by a large inventory of heavy equipment and
              advanced construction management systems.
            </p>
            <p className="font-inter text-sm text-[#6B7280] mt-3 leading-relaxed">
              Our clients include the Federal Government and its agencies, State
              Governments, private companies, estate owners and individuals
              across Nigeria.
            </p>

            {/* Mission & Vision */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
              <div className="bg-white rounded-xl border border-[#E5E7EB] p-5">
                <div className="w-9 h-9 rounded-lg bg-[#EFF6FF] flex items-center justify-center mb-3">
                  <Target size={18} className="text-[#2563EB]" />
                </div>
                <h3 className="font-inter font-semibold text-sm text-[#111827]">
                  Our Mission
                </h3>
                <p className="font-inter text-xs text-[#6B7280] mt-1.5 leading-relaxed">
                  Building and strengthening Nigeria's capacity for sustainable
                  national growth and development through professional integrity
                  and quality engineering services.
                </p>
              </div>
              <div className="bg-white rounded-xl border border-[#E5E7EB] p-5">
                <div className="w-9 h-9 rounded-lg bg-[#EFF6FF] flex items-center justify-center mb-3">
                  <Eye size={18} className="text-[#2563EB]" />
                </div>
                <h3 className="font-inter font-semibold text-sm text-[#111827]">
                  Our Vision
                </h3>
                <p className="font-inter text-xs text-[#6B7280] mt-1.5 leading-relaxed">
                  To highlight technical issues in the engineering construction
                  and supply industry and address the gaps for the growth of the
                  industries and our economy in general.
                </p>
              </div>
            </div>

            {/* Core Values */}
            <div className="mt-6">
              <h3 className="font-inter font-semibold text-sm text-[#111827] mb-3">
                Core Values
              </h3>
              <div className="flex flex-wrap gap-2">
                {coreValues.map((v) => (
                  <span
                    key={v.label}
                    className="inline-flex items-center gap-1.5 bg-white border border-[#E5E7EB] rounded-full px-3 py-1.5 text-xs font-inter text-[#374151]"
                  >
                    <v.icon size={12} className="text-[#2563EB]" />
                    {v.label}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
