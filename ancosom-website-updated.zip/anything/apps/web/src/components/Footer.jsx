import {
  MapPin,
  Phone,
  Mail,
  Clock,
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
} from "lucide-react";

const quickLinks = [
  { label: "Home", href: "#hero" },
  { label: "About Us", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Projects", href: "#projects" },
  { label: "Contact", href: "#contact" },
];

const serviceLinks = [
  { label: "Building Construction", href: "#services" },
  { label: "Roads & Bridges", href: "#services" },
  { label: "Erosion & Drainage Control", href: "#services" },
  { label: "Electrical Services", href: "#services" },
  { label: "Borehole & Utilities", href: "#services" },
  { label: "Procurement & Supply", href: "#services" },
  { label: "Project Management", href: "#services" },
];

const socialLinks = [
  { icon: Facebook, href: "#", label: "Facebook" },
  { icon: Twitter, href: "#", label: "Twitter" },
  { icon: Linkedin, href: "#", label: "LinkedIn" },
  { icon: Instagram, href: "#", label: "Instagram" },
];

export default function Footer({ logoUrl }) {
  const scrollTo = (href) => {
    const el = document.getElementById(href.replace("#", ""));
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <footer className="bg-[#0f172a] text-white">
      {/* Newsletter Bar */}
      <div className="border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div>
              <h3 className="font-inter font-semibold text-lg tracking-tight">
                Stay Updated
              </h3>
              <p className="font-inter text-sm text-white/60 mt-1">
                Subscribe for engineering insights and company updates.
              </p>
            </div>
            <div className="flex w-full md:w-auto gap-2">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 md:w-72 px-4 py-2.5 bg-white/10 border border-white/20 rounded-lg text-sm font-inter text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
              <button className="bg-[#2563EB] text-white text-sm font-inter font-medium px-5 py-2.5 rounded-lg hover:bg-[#1d4ed8] transition-colors whitespace-nowrap">
                Subscribe
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-12">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              {logoUrl ? (
                <img
                  src={logoUrl}
                  alt="ANCOSOM Nigeria"
                  className="h-8 w-8 object-contain"
                />
              ) : (
                <div className="h-8 w-8 bg-[#2563EB] rounded-sm flex items-center justify-center">
                  <span className="text-white font-inter font-semibold text-sm">
                    A
                  </span>
                </div>
              )}
              <div>
                <span className="font-inter font-semibold text-sm tracking-tight text-white block leading-none">
                  ANCOSOM NIGERIA LIMITED
                </span>
                <span className="font-inter text-[10px] tracking-wide text-white/50 leading-none mt-0.5 block">
                  ENGINEERS & BUILDERS · RC 107744
                </span>
              </div>
            </div>
            <p className="font-inter text-sm text-white/60 leading-relaxed mb-6">
              Building and Strengthening Nigeria's Capacity for Sustainable
              National Growth and Development.
            </p>
            <div className="flex items-center gap-3">
              {socialLinks.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  aria-label={s.label}
                  className="w-9 h-9 rounded-full border border-white/20 flex items-center justify-center text-white/60 hover:text-white hover:border-white/40 transition-colors"
                >
                  <s.icon size={16} />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-inter font-semibold text-sm text-white mb-4 tracking-tight">
              Quick Links
            </h4>
            <ul className="space-y-2.5">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={() => scrollTo(link.href)}
                    className="font-inter text-sm text-white/60 hover:text-white transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-inter font-semibold text-sm text-white mb-4 tracking-tight">
              Our Services
            </h4>
            <ul className="space-y-2.5">
              {serviceLinks.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={() => scrollTo(link.href)}
                    className="font-inter text-sm text-white/60 hover:text-white transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-inter font-semibold text-sm text-white mb-4 tracking-tight">
              Contact Us
            </h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <MapPin
                  size={16}
                  className="text-[#2563EB] mt-0.5 flex-shrink-0"
                />
                <span className="font-inter text-sm text-white/60">
                  Suite 30, Danziya Plaza, Opp NNPC Mega Filling Station,
                  Central Area District, Abuja
                </span>
              </li>
              <li className="flex items-start gap-3">
                <MapPin
                  size={16}
                  className="text-[#2563EB] mt-0.5 flex-shrink-0"
                />
                <span className="font-inter text-sm text-white/60">
                  Branch: 5 Evans Timothy Street, Action Layout, Bwari Area
                  Council, Abuja FCT
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={16} className="text-[#2563EB] flex-shrink-0" />
                <span className="font-inter text-sm text-white/60">
                  08039432214 / 08168706371
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={16} className="text-[#2563EB] flex-shrink-0" />
                <span className="font-inter text-sm text-white/60">
                  ancosomenigltd@yahoo.com
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Clock size={16} className="text-[#2563EB] flex-shrink-0" />
                <span className="font-inter text-sm text-white/60">
                  Mon – Fri: 8:00 AM – 5:00 PM
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="font-inter text-xs text-white/40">
            © {new Date().getFullYear()} ANCOSOM NIGERIA LIMITED (RC 107744).
            All Rights Reserved.
          </p>
          <div className="flex items-center gap-4">
            <a
              href="#"
              className="font-inter text-xs text-white/40 hover:text-white/60 transition-colors"
            >
              Privacy Policy
            </a>
            <a
              href="#"
              className="font-inter text-xs text-white/40 hover:text-white/60 transition-colors"
            >
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
